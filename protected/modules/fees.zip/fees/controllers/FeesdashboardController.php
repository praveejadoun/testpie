<?php

class FeesdashboardController extends RController
{
	public function actionIndex()
	{
		$this->render('index');
	}
}